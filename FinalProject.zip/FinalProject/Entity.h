#pragma once
#include "Mesh.h"
#include "transform.h"
#include "Material.h"
#include "BufferStructs.h"

using namespace Microsoft;
using namespace WRL;

class Entity
{
public:
	// constructor
	Entity(Mesh* Mesh, Material* Mat);
	~Entity();

	// getters
	Mesh* GetMesh();
	transform* GetTransform();

	// draws the thing
	void Draw(ComPtr<ID3D11DeviceContext> context, Camera* camera);
	void Draw(ComPtr<ID3D11DeviceContext> context, Camera* camera, XMFLOAT4X4 parentWorld);

private:
	transform trans;
	Mesh* mesh;
	Material* mat;

	// bashful helper
	//void setUpConstant(VertexShaderExternalData vsData, ComPtr<ID3D11DeviceContext> context, ComPtr<ID3D11Buffer> constantBufferVS);
};

