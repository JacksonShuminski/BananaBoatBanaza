#include "player.h"

player::player(std::vector<Entity> body)
{
	parts = body;
	trans = transform();
}

void player::Draw(ComPtr<ID3D11DeviceContext> context, Camera* camera)
{
	for (int i = 0; i < parts.size(); i++)
	{
		parts[i].Draw(context, camera, trans.GetWorldMatrix());
	}
}
