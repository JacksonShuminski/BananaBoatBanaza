#include "Sky.h"

Sky::Sky(Mesh* mesh, Microsoft::WRL::ComPtr<ID3D11SamplerState> sampler, Microsoft::WRL::ComPtr<ID3D11Device> device,
	SimplePixelShader* pixelShader, SimpleVertexShader* vertexShader, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture)
{
	this->mesh = mesh;
	this->sampler = sampler;

	cubeTexture = texture;
	this->pixelShader = pixelShader;
	this->vertexShader = vertexShader;

	D3D11_RASTERIZER_DESC rasterDesc = {};
	rasterDesc.FillMode = D3D11_FILL_SOLID;
	rasterDesc.CullMode = D3D11_CULL_FRONT;
	device.Get()->CreateRasterizerState(&rasterDesc, rasterizer.GetAddressOf());

	D3D11_DEPTH_STENCIL_DESC depthDesc = {};
	depthDesc.DepthEnable = true;
	depthDesc.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
	device.Get()->CreateDepthStencilState(&depthDesc, depthBuffer.GetAddressOf());


}

void Sky::Draw(Microsoft::WRL::ComPtr<ID3D11DeviceContext> context, Camera* camera)
{
	context.Get()->RSSetState(rasterizer.Get());
	context.Get()->OMSetDepthStencilState(depthBuffer.Get(), 0);

	pixelShader->SetShader();
	vertexShader->SetShader();

	// we need this info
	UINT stride = sizeof(Vertex);
	UINT offset = 0;

	// sets buffers
	context->IASetVertexBuffers(0, 1, mesh->GetVertexBuffer().GetAddressOf(), &stride, &offset);
	context->IASetIndexBuffer(mesh->GetIndexBuffer().Get(), DXGI_FORMAT_R32_UINT, 0);

	// vs data
	vertexShader->SetMatrix4x4("view", camera->getViewMatrix());
	vertexShader->SetMatrix4x4("proj", camera->getProjectionMatrix());
	vertexShader->CopyAllBufferData(); 

	// ps data
	pixelShader->SetSamplerState("samplerOptions", sampler.Get());
	pixelShader->SetShaderResourceView("cubeTexture", cubeTexture.Get());

	// draw indexed for the shape
	context->DrawIndexed(mesh->GetIndexCount(), 0, 0);

	// reset the states
	context.Get()->RSSetState(0);
	context.Get()->OMSetDepthStencilState(0, 0);
}
