#include "Material.h"

Material::Material(XMFLOAT4 ColorTint, float specualar, SimplePixelShader* PixelShader, SimpleVertexShader* VertexShader, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> tex, Microsoft::WRL::ComPtr<ID3D11SamplerState> sam) {
    colorTint = ColorTint;
    pixelShader = PixelShader;
    vertexShader = VertexShader;
    specularValue = specualar;
    texture = tex;
    sampler = sam;
    hasNormMap = false;
}

Material::Material(XMFLOAT4 ColorTint, float specualar, SimplePixelShader* PixelShader, SimpleVertexShader* VertexShader, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> tex, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> uvMap, Microsoft::WRL::ComPtr<ID3D11SamplerState> sam)
{
    colorTint = ColorTint;
    pixelShader = PixelShader;
    vertexShader = VertexShader;
    specularValue = specualar;
    texture = tex;
    sampler = sam;
    normalMap = uvMap;
    hasNormMap = true;
}

XMFLOAT4 Material::getTint()
{
    return colorTint;
}

SimplePixelShader* Material::getPixelShader()
{
    return pixelShader;
}

SimpleVertexShader* Material::getVertexShader()
{
    return vertexShader;
}

float Material::getSpecularValue()
{
    return specularValue;
}

ID3D11ShaderResourceView* Material::getTexture()
{
    return texture.Get();
}

ID3D11ShaderResourceView* Material::getNormalMap()
{
    return normalMap.Get();
}

ID3D11SamplerState* Material::getSampler()
{
    return sampler.Get();
}

void Material::setTint(float r, float g, float b, float a)
{
    colorTint = { r, g, b, a };
}
