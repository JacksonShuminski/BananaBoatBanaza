#pragma once

#include "DXCore.h"
#include <DirectXMath.h>
#include <wrl/client.h> // Used for ComPtr - a smart pointer for COM objects
#include "Vertex.h"
#include <vector>
#include <iostream>
#include <fstream>

class Mesh
{
public:
	Microsoft::WRL::ComPtr<ID3D11Buffer> GetVertexBuffer();
	Microsoft::WRL::ComPtr<ID3D11Buffer> GetIndexBuffer();
	int GetIndexCount();

	Mesh(Vertex *v, int vertexCount, unsigned int* i, int indiceCount, Microsoft::WRL::ComPtr<ID3D11Device> device);
	Mesh(const char* fileLocation, Microsoft::WRL::ComPtr<ID3D11Device> device);

private:
	Microsoft::WRL::ComPtr<ID3D11Buffer> vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer> indexBuffer;

	int indexCount;

	void CalculateTangents(Vertex* verts, int numVerts, unsigned int* indices, int numIndices);
};

