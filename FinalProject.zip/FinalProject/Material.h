#pragma once
#include "DXCore.h"
#include <DirectXMath.h>
#include "SimpleShader.h"
#include "Camera.h"
using namespace DirectX;

class Material
{
public:
	// constructor
	Material(XMFLOAT4 colorTint, float specualar, SimplePixelShader* pixelShader, SimpleVertexShader* vertexShader, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> tex, Microsoft::WRL::ComPtr<ID3D11SamplerState> sam);
	Material(XMFLOAT4 colorTint, float specualar, SimplePixelShader* pixelShader, SimpleVertexShader* vertexShader, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> tex, Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> uvMap, Microsoft::WRL::ComPtr<ID3D11SamplerState> sam);

	// gets
	XMFLOAT4 getTint();
	SimplePixelShader* getPixelShader();
	SimpleVertexShader* getVertexShader();
	float getSpecularValue();
	ID3D11ShaderResourceView* getTexture();
	ID3D11ShaderResourceView* getNormalMap();
	ID3D11SamplerState* getSampler();

	// sets
	void setTint(float r, float g, float b, float a);

	bool hasNormMap;

private:

	float specularValue;
	XMFLOAT4 colorTint;

	// textures
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>	texture;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>	normalMap;
	Microsoft::WRL::ComPtr<ID3D11SamplerState>			sampler;

	SimplePixelShader*		pixelShader;
	SimpleVertexShader*		vertexShader;

};

