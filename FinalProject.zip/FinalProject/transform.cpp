#include "transform.h"
#include "BufferStructs.h"

// constructors
transform::transform(XMFLOAT3 pos, XMFLOAT3 scal, XMFLOAT3 rot)
{
	position = pos;
	scale = scal;
	rotation = rot;
	dirty = false;
	XMStoreFloat4x4(&worldMatrix, DirectX::XMMatrixIdentity());
	updateWorldMatrix();
}

transform::transform() {
	position = XMFLOAT3(0.0f, 0.0f, 0.0f);
	scale = XMFLOAT3(1.0f, 1.0f, 1.0f);
	rotation = XMFLOAT3(0, 0, 0);
	dirty = false;
	XMStoreFloat4x4(&worldMatrix, DirectX::XMMatrixIdentity());
	updateWorldMatrix();
}

// setters
void transform::SetPosition(float x, float y, float z)
{
	position = { x, y, z };
	dirty = true;
}

void transform::SetScale(float x, float y, float z)
{
	scale = { x, y, z };
	dirty = true;
}

void transform::SetRotation(float pitch, float yaw, float roll)
{
	rotation = { pitch, yaw, roll };
	dirty = true;
}

// getters
XMFLOAT3 transform::GetPosition()
{
	return position;
}

XMFLOAT3 transform::GetScale()
{
	return scale;
}

XMFLOAT3 transform::GetRotation()
{
	return rotation;
}

XMFLOAT4X4 transform::GetWorldMatrix()
{
	if (dirty) { updateWorldMatrix(); }
	return worldMatrix;
}

// transformers
void transform::MoveAbsolute(float x, float y, float z)
{
	position = { x + position.x, y + position.y, z + position.z };
	dirty = true;
}

void transform::Rotate(float pitch, float yaw, float roll)
{
	rotation = { pitch + rotation.x, yaw + rotation.y, roll + rotation.z };
	dirty = true;
}

void transform::Scale(float x, float y, float z)
{
	scale = { x + scale.x, y + scale.y, z + scale.z };
	dirty = true;
}

void transform::MoveRelative(float x, float y, float z)
{
	XMVECTOR rot = XMQuaternionRotationRollPitchYaw(rotation.x, rotation.y, rotation.z);
	XMVECTOR delta = XMVectorSet(x, y, z, 0);
	delta = XMVector3Rotate(delta, rot);
	XMFLOAT3 result;
	XMStoreFloat3(&result, delta);
	position = { result.x + position.x, result.y + position.y, result.z + position.z };

	dirty = true;
}

void transform::updateWorldMatrix()
{
	// create tranfromation parts
	XMMATRIX trans = XMMatrixTranslationFromVector(XMLoadFloat3(&position));
	XMMATRIX rot = XMMatrixRotationRollPitchYawFromVector(XMLoadFloat3(&rotation)); 
	XMMATRIX sc = XMMatrixScalingFromVector(XMLoadFloat3(&scale));

	// combine and store
	XMMATRIX wm = sc * rot * trans;
	XMStoreFloat4x4(&worldMatrix, wm);

	// clean clean
	dirty = false;

}

