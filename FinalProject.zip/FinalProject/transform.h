#pragma once

#include "DXCore.h"
#include <DirectXMath.h>
#include <wrl/client.h>
using namespace DirectX;

class transform
{
public:
	// constructor 
	transform(XMFLOAT3 pos, XMFLOAT3 scal, XMFLOAT3 rot);
	transform();

	// setters 
	void SetPosition(float x, float y, float z);
	void SetScale(float x, float y, float z);
	void SetRotation(float pitch, float yaw, float roll);

	// getters 
	XMFLOAT3 GetPosition();
	XMFLOAT3 GetScale();
	XMFLOAT3 GetRotation();
	XMFLOAT4X4 GetWorldMatrix();

	// transformers (decepticons!)
	void MoveAbsolute(float x, float y, float z);
	void Rotate(float pitch, float yaw, float roll);
	void Scale(float x, float y, float z);
	void MoveRelative(float x, float y, float z);


private:
	XMFLOAT4X4 worldMatrix;
	XMFLOAT3 position;
	XMFLOAT3 scale;
	XMFLOAT3 rotation;

	bool dirty;

	void updateWorldMatrix();
};

