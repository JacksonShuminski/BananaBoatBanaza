#include "Camera.h"

Camera::Camera(XMFLOAT3 initPos, float aspectRatio, float CfieldOfViewAngle, float CnearPlane, float CfarPlane, float CmoveSpeed, float Csensitivity)
{
	trans = transform(initPos, { 1,1,1 }, { 0,0,0 });

	fieldOfViewAngle = CfieldOfViewAngle;
	nearPlane = CnearPlane;
	farPlane = CfarPlane;
	moveSpeed = CmoveSpeed;
	sensitivity = Csensitivity;

	UpdateProjectionMatrix(aspectRatio);
	UpdateViewMatrix();

}

// updaters
void Camera::UpdateViewMatrix()
{
	// gets position
	XMVECTOR pos = XMLoadFloat3(&trans.GetPosition());
	// gets forward
	XMVECTOR rot = XMQuaternionRotationRollPitchYaw(trans.GetRotation().x, trans.GetRotation().y, trans.GetRotation().z);
	XMVECTOR forward = XMVectorSet(0, 0, 1, 0);
	forward = XMVector3Rotate(forward, rot);
	// stores view matrix
	XMMATRIX view = XMMatrixLookToLH(pos, forward, XMVectorSet(0, 1, 0, 0));
	XMStoreFloat4x4(&viewMatrix, view);
}

void Camera::UpdateProjectionMatrix(float aspectRatio)
{
	 XMMATRIX proj = XMMatrixPerspectiveFovLH(fieldOfViewAngle, aspectRatio, nearPlane, farPlane);
	 XMStoreFloat4x4(&projectionMatrix, proj);
}

void Camera::Update(float deltaTime, HWND windowHandle)
{
	float sprint = 1;
	bool turning = false;
	bool dirty = false;

	// transforming
	if (GetAsyncKeyState(VK_SHIFT) & 0x8000) { sprint = 2; }
	if (GetAsyncKeyState(VK_CONTROL) & 0x8000) { sprint = 0.5f; }
	if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) { turning = true;	dirty = true; }

	// moving
	
	if (GetAsyncKeyState('W') & 0x8000) { trans.MoveRelative(0, 0, deltaTime * moveSpeed * sprint);			dirty = true; }
	if (GetAsyncKeyState('S') & 0x8000) { trans.MoveRelative(0, 0, -deltaTime * moveSpeed * sprint);		dirty = true; }
	if (GetAsyncKeyState('A') & 0x8000) { trans.MoveRelative(-deltaTime * moveSpeed * sprint, 0, 0);		dirty = true; }
	if (GetAsyncKeyState('D') & 0x8000) { trans.MoveRelative(deltaTime * moveSpeed * sprint, 0, 0);			dirty = true; }
	if (GetAsyncKeyState(VK_SPACE) & 0x8000) { trans.MoveAbsolute(0, deltaTime * moveSpeed * sprint, 0);	dirty = true; }
	if (GetAsyncKeyState('X') & 0x8000) { trans.MoveAbsolute(0, -deltaTime * moveSpeed * sprint, 0);		dirty = true; }
	

	// handles turning 
	POINT mousePos = {}; 
	GetCursorPos(&mousePos); 
	ScreenToClient(windowHandle, &mousePos);

	if (turning) 
	{
		float deltaX = mousePos.x - lastMousePos.x;
		float deltaY = mousePos.y - lastMousePos.y;

		trans.Rotate(deltaY * deltaTime * sensitivity, deltaX * deltaTime * sensitivity, 0 );
	}

	if (dirty) { UpdateViewMatrix(); }

	lastMousePos = mousePos;
}

// getters
XMFLOAT4X4 Camera::getViewMatrix()
{
	return viewMatrix;
}

XMFLOAT4X4 Camera::getProjectionMatrix()
{
	return projectionMatrix;
}

XMFLOAT3 Camera::getPos()
{
	return trans.GetPosition();
}

void Camera::setPos(float x, float y, float z)
{
	trans.SetPosition(x, y, z);
	UpdateViewMatrix();
}

void Camera::setRot(float x, float y, float z)
{
	trans.SetRotation(x, y, z);
	UpdateViewMatrix();
}

transform Camera::GetTransform()
{
	return trans;
}
