#pragma once

#include "DXCore.h"
#include <DirectXMath.h>
#include <wrl/client.h> // Used for ComPtr - a smart pointer for COM objects
#include <vector>

#include "BufferStructs.h"
#include "Entity.h"
#include "Camera.h"
#include "Light.h"
#include "Sky.h"
#include "player.h"
#include "Emitter.h"

#include "packages\directxtk_desktop_2017.2020.9.30.1\include\WICTextureLoader.h"

class Game 
	: public DXCore
{

public:
	Game(HINSTANCE hInstance);
	~Game();

	// Overridden setup and game loop methods, which
	// will be called automatically
	void Init();
	void OnResize();
	void Update(float deltaTime, float totalTime);
	void Draw(float deltaTime, float totalTime);

	void ResizePostProcessResources();

private:
	// game stuff
	float moveSpeed;
	float asteroidSpeed;

	// light struct
	DirectionalLight light1;
	DirectionalLight light2;
	DirectionalLight light3;

	// Initialization helper methods - feel free to customize, combine, etc.
	void LoadShaders(); 
	void CreateBasicGeometry();
	
	// entities
	std::vector<Entity*> entities;

	// meshes
	std::vector<Mesh*> meshes;

	// materials
	Material* rock;
	Material* banana;

	// textures
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> rockTex;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> bananaTex;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> rockNorm;
	Microsoft::WRL::ComPtr<ID3D11SamplerState> sampler1;
	
	// the sky 
	Sky* skyBox;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> cubeMap;
	SimplePixelShader* SkyPixelShader;
	SimpleVertexShader* SkyVertexShader;


	// holds the camera
	Camera* camera;
	float aspectRatio;

	
	// Note the usage of ComPtr below
	//  - This is a smart pointer for objects that abide by the
	//    Component Object Model, which DirectX objects do
	//  - More info here: https://github.com/Microsoft/DirectXTK/wiki/ComPtr

	// Buffers to hold actual geometry data
	Microsoft::WRL::ComPtr<ID3D11Buffer> vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer> indexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer> constantBufferVS;
	
	// Shaders and shader-related constructs
	SimplePixelShader* pixelShader;
	SimpleVertexShader* vertexShader;
	SimplePixelShader* normPixelShader;
	SimpleVertexShader* normVertexShader;
	Microsoft::WRL::ComPtr<ID3D11InputLayout> inputLayout;


	// Post processing resources
	int currentBlur;
	float blurDecay;
	float blurDecayAcc;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> ppRTV;		// Allows us to render to a texture
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> ppSRV;		// Allows us to sample from the same texture
	SimpleVertexShader* ppVS;
	SimplePixelShader* ppPS;
	void Blur();

	// CPU particle resources
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> particleTexture;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> particleAnimatedTexture;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilState> particleDepthState;
	Microsoft::WRL::ComPtr<ID3D11BlendState> particleBlendState;
	Microsoft::WRL::ComPtr<ID3D11RasterizerState> particleDebugRasterState;
	SimpleVertexShader* particleVS;
	SimplePixelShader* particlePS;
	Emitter* emitter;

};

