#pragma once

#include "transform.h"
#include "DXCore.h"
#include <DirectXMath.h>

class Camera
{
public:
	Camera(XMFLOAT3 initPos, float aspectRatio, float CfieldOfViewAngle, float CnearPlane, float CfarPlane, float CmoveSpeed, float Csensitivity);

	// updaters
	void UpdateViewMatrix();
	void UpdateProjectionMatrix(float aspectRatio);
	void Update(float deltaTime, HWND windowHandle);

	// getters
	XMFLOAT4X4 getViewMatrix();
	XMFLOAT4X4 getProjectionMatrix();
	XMFLOAT3 getPos();
	void setPos(float x, float y, float z);
	void setRot(float x, float y, float z);
	transform GetTransform();

private:

	transform trans;
	
	XMFLOAT4X4 viewMatrix;
	XMFLOAT4X4 projectionMatrix;

	float fieldOfViewAngle;
	float nearPlane;
	float farPlane;
	float moveSpeed;
	float sensitivity;
	POINT lastMousePos;
};

