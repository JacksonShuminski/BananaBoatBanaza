#pragma once
#include "Mesh.h"
#include "transform.h"
#include "Material.h"
#include "BufferStructs.h"
#include "Entity.h"
#include <vector>

using namespace Microsoft;
using namespace WRL;

class player
{
public:
	player(std::vector<Entity> body);
	void Draw(ComPtr<ID3D11DeviceContext> context, Camera* camera);

	transform trans;
private:
	std::vector<Entity> parts;
};

