#pragma once
#include "Mesh.h"
class Quad :
    public Mesh
{
public:
    Quad(ID3D11Device* device);
    Quad();

private:
    Vertex* GetVerticies();
    unsigned int* GetIndices();
    //Vertex* vertices;
};

