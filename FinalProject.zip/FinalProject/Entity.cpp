#include "Entity.h"

// build em up
Entity::Entity(Mesh* Mesh, Material* Mat)
{
    mesh = Mesh;
	mat = Mat;
    trans = transform();
}

// tear em down
Entity::~Entity()
{
}

// get em!
Mesh* Entity::GetMesh()
{
    return mesh;
}

transform* Entity::GetTransform()
{
    return &trans;
}

// draw methods
void Entity::Draw(Microsoft::WRL::ComPtr<ID3D11DeviceContext> context, Camera* camera)
{
	mat->getPixelShader()->SetShader();
	mat->getVertexShader()->SetShader();

	// we need this info
	UINT stride = sizeof(Vertex);
	UINT offset = 0;

	// sets buffers
	context->IASetVertexBuffers(0, 1, mesh->GetVertexBuffer().GetAddressOf(), &stride, &offset);
	context->IASetIndexBuffer(mesh->GetIndexBuffer().Get(), DXGI_FORMAT_R32_UINT, 0);
	
	// sends buffer data
	SimpleVertexShader* vs = mat->getVertexShader(); 
	vs->SetFloat4("colorTint", mat->getTint());
	vs->SetMatrix4x4("world", trans.GetWorldMatrix());
	vs->SetMatrix4x4("view", camera->getViewMatrix()); 
	vs->SetMatrix4x4("proj", camera->getProjectionMatrix());
	vs->SetFloat3("cameraPos", camera->getPos());
	vs->SetFloat("sepcularIntensity", mat->getSpecularValue());
	

	vs->CopyAllBufferData();

	SimplePixelShader* ps = mat->getPixelShader();
	ps->SetSamplerState("samplerOptions", mat->getSampler());
	ps->SetShaderResourceView("diffuseTexture", mat->getTexture());
	if (mat->hasNormMap) {
		ps->SetShaderResourceView("normalMap", mat->getNormalMap());
	}


	// draw indexed for the shape
	context->DrawIndexed(mesh->GetIndexCount(), 0, 0);
}

void Entity::Draw(Microsoft::WRL::ComPtr<ID3D11DeviceContext> context, Camera* camera, XMFLOAT4X4 parentWorld)
{
	mat->getPixelShader()->SetShader();
	mat->getVertexShader()->SetShader();

	// we need this info
	UINT stride = sizeof(Vertex);
	UINT offset = 0;

	// sets buffers
	context->IASetVertexBuffers(0, 1, mesh->GetVertexBuffer().GetAddressOf(), &stride, &offset);
	context->IASetIndexBuffer(mesh->GetIndexBuffer().Get(), DXGI_FORMAT_R32_UINT, 0);

	// sends buffer data
	SimpleVertexShader* vs = mat->getVertexShader();
	vs->SetFloat4("colorTint", mat->getTint());

	// multiply the child matrix by the parent
	XMMATRIX child = XMLoadFloat4x4(&trans.GetWorldMatrix());
	XMMATRIX parent = XMLoadFloat4x4(&parentWorld);
	XMMATRIX product = XMMatrixMultiply(child, parent);
	XMFLOAT4X4 world;
	XMStoreFloat4x4(&world, product);
	
	vs->SetMatrix4x4("world", world);
	vs->SetMatrix4x4("view", camera->getViewMatrix());
	vs->SetMatrix4x4("proj", camera->getProjectionMatrix());
	vs->SetFloat3("cameraPos", camera->getPos());
	vs->SetFloat("sepcularIntensity", mat->getSpecularValue());
	

	vs->CopyAllBufferData();

	SimplePixelShader* ps = mat->getPixelShader();
	ps->SetSamplerState("samplerOptions", mat->getSampler());
	ps->SetShaderResourceView("diffuseTexture", mat->getTexture());
	if (mat->hasNormMap) {
		ps->SetShaderResourceView("normalMap", mat->getNormalMap());
	}


	// draw indexed for the shape
	context->DrawIndexed(mesh->GetIndexCount(), 0, 0);
}
