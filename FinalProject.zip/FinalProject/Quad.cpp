#include "Quad.h"
#include "Mesh.h"

// For the DirectX Math library
using namespace DirectX;

Quad::Quad(ID3D11Device* device):Mesh(GetVerticies(), 4, GetIndices(), 6, device)
{ }

Quad::Quad()
{
}

Vertex* Quad::GetVerticies()
{
	Vertex v[] = 
	{
		{ XMFLOAT3(-0.5f, -0.5f, +0.0f), XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f) },
		{ XMFLOAT3(+0.5f, -0.5f, +0.0f), XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f) },
		{ XMFLOAT3(+0.5f, +0.5f, +0.0f), XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f) },
		{ XMFLOAT3(-0.5f, +0.5f, +0.0f), XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f) },
	};


	return v;
}

unsigned int* Quad::GetIndices()
{
	unsigned int indices[] = { 0, 1, 2, 3, 0, 2 };
	unsigned int *i = indices;
	
	return i;
}
